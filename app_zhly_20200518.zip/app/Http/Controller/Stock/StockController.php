<?php declare(strict_types=1);

namespace App\Http\Controller\Stock;

use App\Model\Service\DotService;
use App\Model\Service\OrderService;
use App\Model\Service\ProductService;
use App\Model\Service\SystemService;
use App\Http\Middleware\MemberMiddleware;
use App\Http\Middleware\DotMiddleware;
use App\Common\Message;
use Swoft\Bean\BeanFactory;
use Swoft\Http\Message\Request;
use Swoft\Http\Server\Annotation\Mapping\Controller;
use Swoft\Http\Server\Annotation\Mapping\Middleware;
use Swoft\Http\Server\Annotation\Mapping\RequestMapping;
use Swoft\Http\Server\Annotation\Mapping\RequestMethod;
use Swoft\Validator\Annotation\Mapping\Validate;

/**
 * 网点端
 * Class IndexController
 *
 * @Controller(prefix="/api/stock")
 * @Middleware(DotMiddleware::class)
 */
class StockController{

    /**
     * 库存管理员工作台
     *
     * @RequestMapping(route="info",method={RequestMethod::POST})
     * @return array
     */
    public function dotInfo(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();
        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->getStockInfo($params);

        return Message::success($data);

    }
    /**
     * 库存管理员入库确认列表
     * @RequestMapping(route="stockConfirmAddList",method={RequestMethod::POST})
     * @return array
     */
    public function dotStockConfirmAddList(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();
        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotStockConfirmAddList($params);

        return Message::success($data);
    }
    /**
     * 库存管理员出库列表
     * @RequestMapping(route="stockConfirmOutList",method={RequestMethod::POST})
     * @return array
     */
    public function dotStockConfirmOutList(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotStockConfirmOutList($params);

        return Message::success($data);

    }

    /**
     * 库存管理员入库确认
     * @RequestMapping(route="stockConfirmAdd",method={RequestMethod::POST})
     * @return array
     */
    public function dotStockConfirmAdd(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotStockConfirmAdd($params);

        return Message::success($data);
    }

    /**
     * 库存管理员出库确认
     * @RequestMapping(route="stockConfirmOut",method={RequestMethod::POST})
     * @return array
     */
    public function dotStockConfirmOut(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotStockConfirmOut($params);

        return Message::success($data);
    }

    /**
     * 商品报损
     * @RequestMapping(route="confirmLoss",method={RequestMethod::POST})
     * @return array
     */
    public function dotConfirmLoss(Request $request){

        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotConfirmLoss($params);

        return Message::success($data);

    }

    /**
     * 商品库存列表
     * @RequestMapping(route="productStockList",method={RequestMethod::POST})
     * @return array
     */
    public function dotProductStockList(Request $request){
        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotProductStockList($params);

        return Message::success($data);
    }

    /**
     * 库存详情
     * @RequestMapping(route="productStockDetails",method={RequestMethod::POST})
     * @return array
     */
    public function dotProductStockDetails(Request $request){

        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->dotProductStockDetails($params);

        return Message::success($data);

    }

    /**
     * 库存变动记录列表
     * @RequestMapping(route="getStockChangeList",method={RequestMethod::POST})
     * @return array
     */
    public function getStockChangeList(Request $request){

        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->getStockChangeList($params);

        return Message::success($data);

    }

    /**
     * @RequestMapping(route="getStockChangeDetails",method={RequestMethod::POST})
     * @param Request $request
     */
    public function getStockChangeDetails(Request $request){

        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->getStockChangeDetails($params);

        return Message::success($data);
    }

    /**
     * 变动明细（订单出库）
     * @RequestMapping(route="getStockChangeOrderDetails",method={RequestMethod::POST})
     * @param Request $request
     */
    public function getStockChangeOrderDetails(Request $request){

        //获取请求参数
        $params = $request->getParsedBody();

        /** @var DotService $DotService */
        $dotService = BeanFactory::getBean(DotService::class);

        $data = $dotService->getStockChangeOrderDetails($params);

        return Message::success($data);
    }

}