<?php
/**
 * Created by PhpStorm.
 * User: liuxiaodong
 * Date: 2019/1/13
 * Time: 22:45
 */

namespace App\Common;


class StatusEnum
{
    const LoginFailCode = 1001;//登录失败码
    const FailCode = 1005;//失败码
    const SuccessCode = 200;//成功码

    const CALL_BACK_CODE = 1002;//微信回返回码
}