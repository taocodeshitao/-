<?php
namespace App\Model\Service;


use App\Common\Cache;
use App\Exception\ApiException;
use App\Listener\Event;
use App\Model\Dao\ActivityDao;
use App\Model\Dao\ActivityMemberDao;
use App\Model\Dao\ActivityProductDao;
use App\Model\Dao\GradeApiConfigDao;
use App\Model\Dao\GradeDao;
use App\Model\Dao\MemberDao;
use App\Model\Dao\CardRecordDao;
use App\Model\Dao\DotDao;
use App\Model\Dao\UserDao;
use App\Utils\Check;
use Firebase\JWT\JWT;
use Swoft\Bean\Annotation\Mapping\Bean;
use Swoft\Bean\Annotation\Mapping\Inject;
use Swoft\Bean\BeanFactory;
use Swoft\Db\DB;
use Swoft\Redis\Redis;

/**
 * 会员操作逻辑
 * Class MemberService
 *
 * @Bean(scope=Bean::PROTOTYPE)
 */
class MemberService
{

    /**
     * @Inject()
     * @var DotDao
     */
    private $dotDao;

    /**
     * @Inject()
     * @var MemberDao
     */
    private $memberDao;
    /**
     * @Inject()
     * @var ActivityMemberDao
     */
    private $activityMemberDao;


    /**
     * @Inject()
     * @var ActivityProductDao
     */
    private $activityProductDao;

    /**
     * @Inject()
     * @var GradeApiConfigDao
     */
    private $gradeApiConfigDao;


    /**
     * @Inject()
     * @var ActivityDao
     */
    private $activityDao;

    /**
     * @Inject()
     * @var GradeDao
     */
    private $gradeDao;



    /**
     * 网点客户登录
     * @param int $user_id
     * @param string $account_$password
     * @return  array
     * @throws ApiException
     */
    public  function login($params)
    {
        /*$str = $params['sResponseXml'];
        if (empty($str)) throw new ApiException('用户标识为空');*/

        $str='<Response><Head><ResultType>Y</ResultType><CryptType>2</CryptType><StateType>1</StateType></Head><Body>/qigtuR2GX2aR5z+z329BFyxpv1AvK5ke9fMJBW7Emob9hG6xurMDiQW9AoTA2bgDS36z/8tRDYW8sFiT9Xlqj68BzRWBkDdDS36z/8tRDbFrV7oWp+zDejcxb753wQTynDAW7cIM5KRGs63Dqp5E8tY8XVDJCs/DLoUgMVTLHMFmQbzKrIlsMuNyF0ZxIkvZikJZmLqaTUZHNL7/Jh7jjXA85/vJ1S/sBcOxBICXU2x0bFuMuzx4sBRdPVlllP0dySMlkWK4xXwssPjQlw62FvpTRJq7rpVwCNmzd8Xbcl+ZPQmpxHgHUpRK5xhj3zGd99UzBLjZom/fl87UDuS22HJhZNsxxbBd3im31ofHcPfZ+kVqd+OQUF0lcybh21mSPiG84eQwfbkFXK2YAd1VN/TuU7TSJX616MBxgsgXT6NjbJ9NX/BCNcpWj3tlzzKzX4+JU1DSx5UbXWxECPpdTXz+HIy2a8NoclmQDjmsMiqKHEmETcGembNPDeTw1PlbeZq7MLF6S4FCPzFzry3Crr7b1HgDdzTKjI8cFiNeQDak8eG6wvgtOnCed6GiADR5g+O7r4Agk+Kc4M/K2GkMXOgaIE2Gu6nRhq/EI7fgoHh6mRbimcV6HNWEZzg5UwcNOnx08qdj35ffPx7nxQaDELWpL+YQyhTWRN8ZiZxlMoSImUyHau77ar+OptVbxj42kAENIZZPCpDMQtLddvEHFJ+PHnrbPF4lMHuleWtRpYXh6Y/I+tpAyiUaiNWyTIzl9SgUo/keyTY1NJjAJfU9y108ktRVAbGltC7jY6w4OTgR9rhM/tu/JWBox65TGW9HKBsgFzsC8FB6A4rt+jjteSRfTo2HonGV+yz7VfQhDo0YvS7xVORnGkByMuS1mAj14w5JtfJtnPW5ZdV0TC4QJgaIUBJNqOgop0yrujBSqyinTKu6MFKrKKdMq7owUqsmATe754t3exmJ3Mn2dk1MyaSA4gJZ0LcWDuGdoH7TwIGlV8wOfdlaSWMsV3tWc3+uDOLoqUVMxqJg6jDFY8fBYqCre/aS0LEIzwDdrUksButULlyG+erZU/cgx9FOPr0B5zoLSLkN4sMI4L1SSkbgOmvbdThvRbO0UVsKKTj8k2q/QErXCeM/wyaRvSsjX/cxtsi1+SKYB0UiWcKn0jqac6fxtrxGnpzVa6DztfsucmcJMhiDhpa/3ElYEhWWVFgdt2o+Wi3XMVpk41ZhKA0J2T+A7RgU3tJTNsPx8rlaLpjOb5vaIVbcjoNLRmXBcymHGRGyJXFOZzz8Ju4zbm3bbazRH1y8x+t8hbx39Z0+czfKGDg90xrGHDHr01QZLNUxh4t52sH5uU9cLJYWsJ/bbYBvc9Hct8Q/oVgKS9QC6ZtNUWJshzdaw==</Body></Response>';

        $member_info = $this->apiDecrypt($str);

        $member_code =$member_info['uniqueuserid'];

        //记录用户信息
        $member_data = $this->memberDao->getMemberCode($member_code);
        if (empty($member_data)){//如果没有记录过该用户就新增

            $member_id = $this->memberDao->addMember(['unique_code'=>$member_code,'created_at'=>time()]);
            var_dump($member_id);
        }else{
            $member_id = $member_data['id'];
        }

        $secret_key = config('jwt.secret_key');
        $exp = intval(config('jwt.exp'));
        $type = config('jwt.type');

        //生产网点token
        $payLoad = [
            'member_id' =>$member_id,
            'iat'  => time(),
            'exp'  => time() + $exp
        ];

        //生成加密token
        $token =JWT::encode($payLoad,$secret_key,$type);
        //缓存授权码
        Redis::setex(config('jwt.REDIS_DATEBASE_PREFIX').':MEMBER:LOGIN:'.$token,$exp,json_encode(['member_id'=>$member_id,'unique_code'=>$member_code]));

        return ['member_token'=>$token];

    }

    /**
     * 处理请求返回的结果
     */
    public function apiDecrypt($str){
        $responseObj = (array)simplexml_load_string($str, 'SimpleXMLElement', LIBXML_NOCDATA);
        $responseObj['Head']=(array)$responseObj['Head'];

        if($responseObj['Head']['ResultType']!='Y'){
            //$this->errorPage('登录失败','/','提示','');
            echo '错误';exit;
        }

        //转义空格
        $str=str_replace(' ','+',$responseObj['Body']);
        $data=$this->decrypt($str,config('CMB_KEY'));
        //禁止引用外部xml实体
        libxml_disable_entity_loader(true);
        // 创建解析器
        $parser = xml_parser_create();
        // 将 XML 数据解析到数组中
        xml_parse_into_struct($parser, $data, $vals, $index);
        // 释放解析器
        xml_parser_free($parser);

        $memberInfo=[];
        foreach ($vals as $val){

            if($val['level']==5&&$val['tag']=='UNIQUEUSERID'){
                $memberInfo[strtolower($val['tag'])]=$val['value'];
            }
        }
        if (empty($memberInfo)) throw new ApiException('获取用户信息失败');

        return $memberInfo;
    }


    /**解密
     * @param $text
     * @param $key
     */
    public function decrypt($text,$key)
    {
        $data =  openssl_decrypt ($text, 'des-ecb', $key);
        return $data;
    }

    /**
     * 会员端活动详情
     */
    public function getActivityProductList($params){

        if (empty($params['activity_id'])) throw new ApiException('活动ID错误');

        $token =$params['member_token'];
        $activity_id =$params['activity_id'];

        //获取登录信息
        //获取会员的登录信息
        $member_data = Redis::get(config('jwt.REDIS_DATEBASE_PREFIX').':MEMBER:LOGIN:'.$token);
        $member_data = json_decode($member_data,true);
        if (empty($member_data)) throw new ApiException('会员信息查询失败');


        //验证领取权限
        return $this->checkActivity($activity_id,$member_data['unique_code']);

    }
    /**
     * 验证活动会员是否满足兑换条件
     * @param $activity_id
     * @param $product_id
     * @param int $grade_id
     */
    public function checkActivity($activity_id,$uniqueuserid,$grade_id=0){

        $activity_data =$this->activityDao->getOndByCode($activity_id);
        //查询活动下商品的的档次
        $getActivityProductByIdData=$this->activityProductDao->getActivityProductGrade($activity_id);

        if (empty($getActivityProductByIdData)) throw new ApiException('活动无商品');

        //白名单
        if ($activity_data['member_source']==1){

            //验证是否创建档次
            $gradeData = $this->gradeDao->getOndByCode($activity_id);
            if (empty($gradeData)) throw new ApiException('您没有领取机会了');

            //查询活动一共有几个档次
            $activityMemberGrade =$this->activityMemberDao->getActivityGrade($activity_id,$grade_id);

            //if (empty($activityMemberGrade)) throw new ApiException('线上活动档次未创建');

            $grade_id_data = array_column($activityMemberGrade,'grade_id');

            $grade_status_str=[];


            foreach ($grade_id_data as $v){
                $grade_status_str[$v]=true;
            }

        }

        //接口
        if ($activity_data['member_source']==2){

            $grade_data =  $this->gradeDao->getOndByCode($activity_id);

            if (empty($grade_data)) throw new ApiException('线下活动档次不存在');

            $grade_id_data = array_column($grade_data,'id');
            $grade=[];
            foreach ($grade_id_data as $val){
                $gradeApiData = $this->gradeApiConfigDao->getOneGradeById($val);

                $where_str='?uniqueuserid='.$uniqueuserid;
                $url='';
                foreach ($gradeApiData as $key=>$v){
                    $url=$v['url'];
                    $where_str=$where_str.$v['api_where'].'='.$v['api_val'].'$';
                }

                $where_str = rtrim($where_str, '&');
                $result =post_curl_func($url,$where_str);
                if ($result){
                    $grade[]=$val ;
                }
            }

            $grade_status_str=[];
            foreach ($grade_id_data as $v){
                $grade_status_str[$v]=true;
            }
        }

        return $grade_status_str;
    }


    /**
     * 会员端确认订单
     */
    public function memberConfirmOrderInfo($params){

        if (empty($params['activity_id'])) throw new ApiException('活动ID错误');
        if (empty($params['product_id'])) throw new ApiException('商品ID错误');

        $data = $this->activityDao->getOndByCode($params['activity_id']);
        //线上
        if ($data['activity_type']==1){
            return $this->activityProductDao->getProductActivitById($params['activity_id'],$params['product_id']);
        }else{//线下
            return $this->activityProductDao->getProductActivitByIdxia($params['activity_id'],$params['product_id']);
        }

    }





}